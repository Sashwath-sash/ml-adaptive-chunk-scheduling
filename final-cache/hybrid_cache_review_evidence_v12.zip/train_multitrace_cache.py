"""Train one cache model on two trace families with chronological holdouts."""
import argparse
import json
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier

from cache_admission_probe import feature_rows, read_rows, replay, reuse_labels


def split(rows):
    a, b = int(len(rows) * .6), int(len(rows) * .8)
    return rows[:a], rows[a:b], rows[b:]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--trace-a", type=Path, default=Path("data/browsetrace_full_400_sessions.csv"))
    ap.add_argument("--trace-b", type=Path, default=Path("data/browsetrace_llm_full_901.csv"))
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--capacity", type=int, default=512)
    args = ap.parse_args()
    if args.output.exists():
        ap.error("output already exists")
    groups = {name: split(read_rows(path)) for name, path in (("scripted", args.trace_a), ("llm", args.trace_b))}
    train_x = np.concatenate([feature_rows(groups[name][0]) for name in groups])
    train_y = np.concatenate([reuse_labels(groups[name][0], args.capacity * 2) for name in groups])
    model = HistGradientBoostingClassifier(max_iter=100, max_leaf_nodes=15,
        min_samples_leaf=40, learning_rate=.07, l2_regularization=2, random_state=811)
    model.fit(train_x, train_y)
    stages = {20, 40, 60, 100}
    thresholds = (.1, .2, .3, .4, .5, .6, .7, .8)
    val_rows = {name: group[1] for name, group in groups.items()}
    val_baselines = {name: replay(rows, "second_touch", args.capacity)["misses"]
                     for name, rows in val_rows.items()}
    val_predictions = {}
    for name, rows in val_rows.items():
        val_predictions[name] = {count: pred[:, 1] for count, pred in
            enumerate(model.staged_predict_proba(feature_rows(rows)), 1) if count in stages}
    candidates = []
    for count in sorted(stages):
        for threshold in thresholds:
            misses = {name: replay(val_rows[name], "ml", args.capacity,
                                   val_predictions[name][count], threshold)["misses"]
                      for name in groups}
            ratios = [misses[name] / val_baselines[name] for name in groups]
            candidates.append({"stages": count, "threshold": threshold,
                               "validation_misses": misses,
                               "worst_ratio_to_second_touch": max(ratios),
                               "mean_ratio_to_second_touch": sum(ratios) / len(ratios)})
    chosen = min(candidates, key=lambda c: (c["worst_ratio_to_second_touch"],
                  c["mean_ratio_to_second_touch"], c["stages"]))
    test = {}
    for name, group in groups.items():
        rows = group[2]
        for count, pred in enumerate(model.staged_predict_proba(feature_rows(rows)), 1):
            if count == chosen["stages"]:
                scores = pred[:, 1]
                break
        test[name] = {policy: replay(rows, policy, args.capacity,
                                    scores if policy == "ml" else None, chosen["threshold"])
                      for policy in ("lru", "second_touch", "two_queue", "tinylfu", "ml")}
    export = {"baseline": float(model._baseline_prediction[0, 0]), "trees": []}
    for stage in model._predictors[:chosen["stages"]]:
        export["trees"].append([[int(n["feature_idx"]), float(n["num_threshold"]),
            int(n["left"]), int(n["right"]), bool(n["is_leaf"]), float(n["value"]),
            bool(n["missing_go_to_left"])] for n in stage[0].nodes])
    info = {"scope": "one model trained across two trace families; final 20% of each held out",
            "capacity_entries": args.capacity, "trace_paths": {"scripted": str(args.trace_a), "llm": str(args.trace_b)},
            "split_counts": {name: [len(part) for part in group] for name, group in groups.items()},
            "validation_second_touch_misses": val_baselines,
            "selection_rule": "minimize worst validation misses / second-touch misses across trace families",
            "candidates": candidates, "chosen": chosen, "test": test}
    args.output.mkdir(parents=True)
    joblib.dump(model, args.output / "model.joblib")
    (args.output / "hgb.json").write_text(json.dumps(export))
    (args.output / "results.json").write_text(json.dumps(info, indent=2))
    print(json.dumps({"chosen": chosen, "test": test}, indent=2))


if __name__ == "__main__":
    main()
