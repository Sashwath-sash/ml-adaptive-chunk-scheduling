"""Measure concurrent native cache replay processes with a synchronized start."""
import argparse
import json
import statistics
import subprocess
import time
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--repeats", type=int, default=5)
    ap.add_argument("--input", type=Path, default=Path("cache_native_input_40"))
    ap.add_argument("--sharded", action="store_true", help="Read distinct workerN subdirectories under --input")
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    if args.output.exists():
        ap.error("output already exists")
    if args.workers < 2 or args.workers > 8:
        ap.error("workers must be 2..8")
    root = Path(__file__).resolve().parent
    linux_root = "/mnt/" + root.drive[0].lower() + root.as_posix()[2:]
    prefix = ["wsl.exe", "--cd", linux_root, "-e"]
    subprocess.run(prefix + ["gcc", "-O3", "-std=c11", "-Wall", "-Wextra", "cache_native.c", "-lm", "-o", "cache_native"], check=True)
    runs = []
    policies = ("lru", "second_touch", "two_queue", "s3fifo", "ml")
    for repeat in range(args.repeats):
        for j in range(len(policies)):
            policy = policies[(j + repeat) % len(policies)]
            processes = []
            for worker in range(args.workers):
                worker_input = args.input / f"worker{worker}" if args.sharded else args.input
                cmd = prefix + ["./cache_native", worker_input.as_posix() + "/test_trace.txt",
                                worker_input.as_posix() + "/model.txt", "1", policy, "--sync"]
                processes.append(subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                                  stderr=subprocess.PIPE, text=True, bufsize=1))
            for p in processes:
                if p.stdout.readline().strip() != "READY":
                    raise RuntimeError("worker did not reach synchronization barrier")
            start = time.perf_counter()
            for p in processes:
                p.stdin.write("\n")
                p.stdin.flush()
            outputs = []
            for p in processes:
                out, err = p.communicate()
                if p.returncode:
                    raise RuntimeError(f"worker exit={p.returncode}: {err}")
                outputs.append(json.loads(out)["repeats"][0][0])
            wall = time.perf_counter() - start
            checksums = {o["checksum"] for o in outputs}
            if not args.sharded and len(checksums) != 1:
                raise RuntimeError("workers returned different contents")
            runs.append({"repeat": repeat, "policy": policy, "workers": args.workers,
                         "batch_wall_seconds": wall,
                         "max_worker_loop_seconds": max(o["wall_seconds"] for o in outputs),
                         "sum_direct_reads": sum(o["direct_reads"] for o in outputs),
                         "workers_detail": outputs})
            print(f"repeat={repeat+1} {policy} batch={wall:.3f}s reads={runs[-1]['sum_direct_reads']}", flush=True)
    summary = {policy: {"median_batch_wall_seconds": statistics.median(
                r["batch_wall_seconds"] for r in runs if r["policy"] == policy),
                "sum_direct_reads_per_batch": next(r["sum_direct_reads"] for r in runs if r["policy"] == policy)}
               for policy in policies}
    if args.sharded:
        for repeat in range(args.repeats):
            group = [run for run in runs if run["repeat"] == repeat]
            for worker in range(args.workers):
                assert len({run["workers_detail"][worker]["checksum"] for run in group}) == 1
    args.output.mkdir(parents=True)
    (args.output / "results.json").write_text(json.dumps({"workers": args.workers,
        "sharded": args.sharded,
        "repeats": args.repeats, "runs": runs, "summary": summary,
        "scope": "Separate concurrent user-space processes; each replays a different interleaved request shard if sharded, otherwise the same input. Each has its own cache/backing file. "
                 "Workers synchronize immediately before timed loops; batch time includes process wakeup and completion. "
                 "This tests CPU/storage contention, not a shared cross-process cache."}, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
