"""Paper-based ARC miss-count probe, independent of the native cache code."""
import csv
import json
from collections import OrderedDict
from pathlib import Path


def arc_misses(keys, capacity, scores=None, threshold=.2):
    t1, t2, b1, b2 = (OrderedDict() for _ in range(4))
    p = 0
    misses = 0

    def replace(key):
        if t1 and (len(t1) > p or (key in b2 and len(t1) == p)):
            old, _ = t1.popitem(last=False)
            b1[old] = None
        else:
            old, _ = t2.popitem(last=False)
            b2[old] = None

    for index, key in enumerate(keys):
        if key in t1:
            del t1[key]
            t2[key] = None
            continue
        if key in t2:
            t2.move_to_end(key)
            continue
        misses += 1
        if scores is not None and scores[index] < threshold:
            continue
        if key in b1:
            p = min(capacity, p + max(1, len(b2) // len(b1)))
            replace(key)
            del b1[key]
            t2[key] = None
            continue
        if key in b2:
            p = max(0, p - max(1, len(b1) // len(b2)))
            replace(key)
            del b2[key]
            t2[key] = None
            continue
        if len(t1) + len(b1) == capacity:
            if len(t1) < capacity:
                b1.popitem(last=False)
                replace(key)
            else:
                t1.popitem(last=False)
        elif len(t1) + len(b1) < capacity:
            total = len(t1) + len(t2) + len(b1) + len(b2)
            if total >= capacity:
                if total == 2 * capacity:
                    b2.popitem(last=False)
                replace(key)
        t1[key] = None
        assert len(t1) + len(t2) <= capacity
        assert len(t1) + len(t2) + len(b1) + len(b2) <= 2 * capacity
    return misses


def keys_from_csv(path, final_fraction=False):
    with path.open(encoding="utf-8", newline="") as stream:
        keys = [row["cache_key"] for row in csv.DictReader(stream)]
    return keys[int(len(keys) * .8):] if final_fraction else keys


if __name__ == "__main__":
    ROOT = Path(__file__).resolve().parent
    inputs = {
        "scripted": ("data/browsetrace_full_400_sessions.csv", True),
        "llm": ("data/browsetrace_llm_full_901.csv", True),
        "nasa_aug": ("data/nasa_aug_last_100k_cache.csv", False),
    }
    result = {name: {"requests": len(keys), "arc_direct_reads": arc_misses(keys, 512)}
              for name, (path, fraction) in inputs.items()
              for keys in [keys_from_csv(ROOT / path, fraction)]}
    (ROOT / "results_arc_probe.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
