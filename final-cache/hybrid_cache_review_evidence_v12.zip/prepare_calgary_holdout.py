"""Extract Calgary's last 100,000 successful GETs for an untouched holdout."""
import csv
import gzip
import hashlib
import json
import re
from collections import deque
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "data/calgary_access_log.gz"
OUTPUT = ROOT / "data/calgary_last_100k_cache.csv"
MANIFEST = ROOT / "data/calgary_last_100k_manifest.json"
PATTERN = re.compile(rb'^\S+ - - \[[^]]+\] "GET (\S+) HTTP/[0-9.]+" 200 (\d+)$')
rows = deque(maxlen=100_000)
matched = 0
with gzip.open(SOURCE, "rb") as stream:
    for line in stream:
        parsed = PATTERN.match(line.strip())
        if parsed is None:
            continue
        name = parsed.group(1).decode("latin-1")
        if name.startswith("/"):
            name = name[1:]
        if not name:
            continue
        matched += 1
        rows.append(("http://calgary.cs.ucalgary.ca/" + name, int(parsed.group(2))))
with OUTPUT.open("w", newline="", encoding="utf-8") as stream:
    writer = csv.writer(stream)
    writer.writerow(("cache_key", "object_size_bytes"))
    writer.writerows(rows)
manifest = {"source_url": "https://ita.ee.lbl.gov/html/contrib/Calgary-HTTP.html",
            "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "matched_get_200_requests": matched, "selected_last_requests": len(rows),
            "derived_sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
            "selection": "last 100000 valid GET 200 requests, original order",
            "note": "Different server from training; filenames anonymized at source; excluded from model training/selection."}
MANIFEST.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(json.dumps(manifest, indent=2))
