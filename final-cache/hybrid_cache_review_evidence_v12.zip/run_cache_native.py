"""Build and benchmark the complete native cache replay under WSL."""
import argparse
import json
import statistics
import subprocess
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", type=Path, default=Path("cache_native_input_40"))
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--repeats", type=int, default=9)
    args = ap.parse_args()
    if args.output.exists():
        ap.error("output already exists")
    root = Path(__file__).resolve().parent
    linux_root = "/mnt/" + root.drive[0].lower() + root.as_posix()[2:]
    prefix = ["wsl.exe", "--cd", linux_root, "-e"]
    subprocess.run(prefix + ["gcc", "-O3", "-std=c11", "-Wall", "-Wextra", "cache_native.c", "-lm", "-o", "cache_native"], check=True)
    run = subprocess.run(prefix + ["./cache_native", str(args.input.as_posix() + "/test_trace.txt"),
                                   str(args.input.as_posix() + "/model.txt"), str(args.repeats)],
                         check=True, capture_output=True, text=True)
    data = json.loads(run.stdout)
    by_policy = {policy: [entry for rep in data["repeats"] for entry in rep if entry["policy"] == policy]
                 for policy in ("lru", "second_touch", "two_queue", "s3fifo", "ml")}
    summary = {policy: {"median_wall_seconds": statistics.median(x["wall_seconds"] for x in entries),
                        "range_wall_seconds": [min(x["wall_seconds"] for x in entries),
                                               max(x["wall_seconds"] for x in entries)],
                        "direct_reads": entries[0]["direct_reads"]}
               for policy, entries in by_policy.items()}
    data["summary"] = summary
    data["method_note"] = ("Full online C lookup, history, HGB prediction and O_DIRECT read are timed. "
                           "Backing 4-KiB blocks are deterministic synthetic data mapped from real URL requests; "
                           "reported bytes are direct-read bytes requested, not measured physical disk reads. "
                           "Backing-file creation and model loading are excluded from request-loop timing.")
    args.output.mkdir(parents=True)
    (args.output / "results.json").write_text(json.dumps(data, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
