"""Check data provenance, held-out counts, checksums, and saved native results."""
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads((ROOT / path).read_text())


def check_single(directory, expected, input_dir):
    data = read(directory + "/results.json")
    manifest = read(input_dir + "/manifest.json")
    assert data["requests"] == manifest["test_requests"] == expected["requests"]
    assert data["capacity"] == manifest["capacity"] == 512
    assert data["trees"] == manifest["model_stages"] == 100
    for repetition in data["repeats"]:
        assert {x["policy"] for x in repetition} == set(expected["misses"])
        assert len({x["checksum"] for x in repetition}) == 1
        for x in repetition:
            assert x["direct_reads"] == expected["misses"][x["policy"]]
            assert x["hits"] + x["direct_reads"] == expected["requests"]
            assert x["direct_bytes_requested"] == x["direct_reads"] * 4096
    original = ROOT / expected["trace_path"]
    assert hashlib.sha256(original.read_bytes()).hexdigest() == manifest["trace_sha256"]


def check_concurrent(directory, expected):
    data = read(directory + "/results.json")
    assert data["workers"] == 2
    for run in data["runs"]:
        assert run["sum_direct_reads"] == 2 * expected["misses"][run["policy"]]
        assert len(run["workers_detail"]) == 2
        assert len({x["checksum"] for x in run["workers_detail"]}) == 1


def check_sharded(name, expected):
    data = read(f"results_cache_sharded_{name}_5runs/results.json")
    assert data["workers"] == 2 and data["sharded"] is True
    sizes = []
    for worker in (0, 1):
        manifest = read(f"cache_native_shards_{name}/worker{worker}/manifest.json")
        assert manifest["shard_count"] == 2 and manifest["shard_index"] == worker
        sizes.append(manifest["test_requests"])
        for repeat in range(data["repeats"]):
            group = [r for r in data["runs"] if r["repeat"] == repeat]
            assert {r["policy"] for r in group} == {"lru", "second_touch", "two_queue", "ml"}
            assert len({r["workers_detail"][worker]["checksum"] for r in group}) == 1
            for r in group:
                x = r["workers_detail"][worker]
                assert x["hits"] + x["direct_reads"] == manifest["test_requests"]
    assert sum(sizes) == expected["requests"]
    for r in data["runs"]:
        assert r["sum_direct_reads"] == sum(x["direct_reads"] for x in r["workers_detail"])


def check_five_policy(name, expected, s3_single, s3_shards):
    single = read(f"results_final5_{name}_5runs/results.json")
    expected_five = dict(expected["misses"], s3fifo=s3_single)
    for repetition in single["repeats"]:
        assert {x["policy"] for x in repetition} == set(expected_five)
        assert len({x["checksum"] for x in repetition}) == 1
        for item in repetition:
            assert item["direct_reads"] == expected_five[item["policy"]]
            assert item["direct_bytes_requested"] == 4096 * item["direct_reads"]
    sharded = read(f"results_final5_sharded_{name}_fixed_5runs/results.json")
    assert sharded["workers"] == 2 and sharded["sharded"]
    for run in sharded["runs"]:
        assert run["sum_direct_reads"] == sum(x["direct_reads"] for x in run["workers_detail"])
        if run["policy"] == "s3fifo":
            assert [x["direct_reads"] for x in run["workers_detail"]] == s3_shards
        for worker, item in enumerate(run["workers_detail"]):
            manifest = read(f"cache_native_shards_{name}/worker{worker}/manifest.json")
            assert item["hits"] + item["direct_reads"] == manifest["test_requests"]
    for repeat in range(5):
        group = [run for run in sharded["runs"] if run["repeat"] == repeat]
        assert {run["policy"] for run in group} == set(expected_five)
        for worker in range(2):
            assert len({run["workers_detail"][worker]["checksum"] for run in group}) == 1


def main():
    trained = read("results_cache_multitrace_v1/results.json")
    assert trained["chosen"]["stages"] == 100
    assert trained["chosen"]["threshold"] == .2
    assert trained["split_counts"] == {"scripted": [49473, 16491, 16491],
                                       "llm": [214669, 71556, 71557]}
    spec = {
        "scripted": {"requests": 16491, "misses": {"lru": 8793, "second_touch": 7543,
                      "two_queue": 7655, "ml": 6707},
                      "trace_path": "data/browsetrace_full_400_sessions.csv"},
        "llm": {"requests": 71557, "misses": {"lru": 19713, "second_touch": 19209,
                 "two_queue": 18683, "ml": 18556},
                 "trace_path": "data/browsetrace_llm_full_901.csv"},
    }
    for name, expected in spec.items():
        assert {k: v["misses"] for k, v in trained["test"][name].items()
                if k in expected["misses"]} == expected["misses"]
        check_single(f"results_cache_multitrace_{name}_4policy_9runs", expected,
                     f"cache_native_input_multitrace_{name}")
        check_concurrent(f"results_cache_multitrace_{name}_concurrent_{5 if name == 'scripted' else 3}runs", expected)
        check_sharded(name, expected)
        check_five_policy(name, expected,
                          7773 if name == "scripted" else 18950,
                          [4787, 4757] if name == "scripted" else [11145, 11103])
    print("PASS: split counts, source hashes, offline/native misses, direct bytes, checksums, concurrent totals")


if __name__ == "__main__":
    main()
