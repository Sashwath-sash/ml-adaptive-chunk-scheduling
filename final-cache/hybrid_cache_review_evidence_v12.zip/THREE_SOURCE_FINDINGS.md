# Three-source exploratory cache experiment

This is a reproducible engineering result, not proof of a new cache algorithm or a final student-authored paper.

## Why the model changed

The earlier model trained only on two BrowseTrace families. On an independent NASA July 1995 web-server holdout (the last 100,000 successful GET requests), its native direct-read counts were ML 13,236 versus S3-FIFO 11,040. The failure was observed **before** designing the three-source model. It must not be omitted from any research account.

The revised model uses the first 60% of each BrowseTrace family and the first 150,000 requests of a separately derived 300,000-request July slice for training. Validation uses the next 20% of each BrowseTrace family and July slice requests 150,000–199,999. The final 100,000 July slice requests are unused by this revised training/selection, but overlap the earlier exploratory failure, so they are **not** a blind test. The subsequent NASA August 1995 log (last 100,000 successful GET requests) was not opened for model training or validation. July and August share a website, so August tests temporal transfer, not a new application domain.

The HGB model has 100 stages, 15 maximum leaves per stage, and a frozen admission threshold of 0.2. Stage count and threshold were selected on the three validation slices against the best of four simple baselines in each slice, then exported for the C replay. The training target is reuse within the next 1,024 requests. Online inference sees only current request fields and prior history. Every cache policy reads the same deterministic 4-KiB backing blocks through Linux `O_DIRECT` on a miss. This is a user-space prototype, not kernel integration or real original HTTP response-body replay.

## Frozen-model held-out results

| Test requests | LRU reads | Second-touch | Simplified 2Q | Local S3-FIFO | Revised ML | ML reduction vs lowest non-ML |
|---|---:|---:|---:|---:|---:|---:|
| BrowseTrace A, final 16,491 | 8,793 | 7,543 | 7,655 | 7,773 | 6,827 | 9.5% |
| BrowseTrace B, final 71,557 | 19,713 | 19,209 | 18,683 | 18,950 | 18,501 | 1.0% |
| NASA August, final 100,000 | 10,000 | 9,656 | 9,670 | 8,349 | 8,270 | 0.9% |

All policies produced matching output checksums within each replay. This is a read-count result across three related web-request settings, **not** a speedup guarantee. In the three-run native August test, median loop times were ML 1.694 s and S3-FIFO 2.179 s, but ranges overlapped and one LRU run was 12.704 s, showing substantial system noise.

A subsequent paper-based Python ARC replacement replay (`arc_reference_probe.py`) produced 7,430, 17,913, and 8,792 misses on those same three tests. **ARC beats ML on BrowseTrace B** (17,913 vs 18,501), while ML beats ARC on BrowseTrace A and NASA August. ARC was not integrated into the timed native C loop, so this is only an offline miss-count comparison. It rules out the claim that ML dominates all reasonable existing cache policies.

For August requests split alternately between two concurrent processes with separate 512-entry caches, three-run totals were ML 8,860 versus S3-FIFO 8,977, a 1.3% read reduction. Median batch times were 0.833 s and 0.900 s, respectively, again only local observations. This is not a shared cross-process cache.

## Reproduce and inspect

1. `python verify_three_source.py` checks the saved results, source hashes, counts, policy checksums, and frozen model settings.
2. `python demo_cache_final.py` demonstrates the older two-source model; use `python run_cache_native.py --input cache_native_input_nasa_aug_v1 --output NEW_DIRECTORY --repeats 3` to run the revised August model fresh. The output directory must not already exist.
3. `python run_cache_concurrent.py --sharded --input cache_native_shards_nasa_aug_v1 --output NEW_DIRECTORY --repeats 3` reruns the two-process August test.
4. `python arc_reference_probe.py` recomputes the paper-based ARC miss counts. `python probe_tinylfu_native.py` verifies the native frequency-admission policy against an independent Python replay on the two original held-out traces. The latter baseline is deliberately simplified; it is not a production Caffeine/W-TinyLFU implementation.

Source data: [BrowseTrace](https://github.com/landigf/BrowseTrace) and the redistributed [NASA HTTP logs](https://github.com/greymd/NASA-HTTP). See `data/nasa_jul_last_300k_manifest.json` and `data/nasa_aug_last_100k_manifest.json` for exact hashes and extraction. Client host identifiers and timestamps are omitted from the derived NASA CSVs; the original compressed log files are not in the shareable package.

## What is not established

ARC reverses the ML win on one of the three tests, and the read advantages against the strongest *native* non-ML policy are small in two of three tests. Only one capacity (512 x 4 KiB), one old web server, and two related BrowseTrace families are evaluated. S3-FIFO and ARC are local paper-based implementations, not the authors' optimized releases; GDSF and other learned caches are not compared. The measured direct-read bytes are requested bytes, not physical storage traffic; the original response bodies are unavailable. No reliable cross-machine total-time or novelty claim follows. A supervisor must accept the change from CPU chunk scheduling to I/O chunk caching, and the student must write the original final paper and required 30-paper survey.
