"""Probe fixed-total per-worker cache allocation on chronological trace splits."""
import json
from pathlib import Path

import joblib

from cache_admission_probe import feature_rows, read_rows, replay

ROOT = Path(__file__).resolve().parent
model = joblib.load(ROOT / "results_cache_three_source_v1/model.joblib")
paths = {"a": ROOT / "data/browsetrace_full_400_sessions.csv",
         "b": ROOT / "data/browsetrace_llm_full_901.csv"}
rows = {}
scores = {}
for name, path in paths.items():
    all_rows = read_rows(path)
    a, b = int(len(all_rows) * .6), int(len(all_rows) * .8)
    rows[name] = {"validation": all_rows[a:b], "test": all_rows[b:]}
    scores[name] = {part: model.predict_proba(feature_rows(items))[:, 1]
                    for part, items in rows[name].items()}
capacities = tuple(range(128, 897, 128))
policies = ("lru", "second_touch", "two_queue", "ml")
misses = {}
for part in ("validation", "test"):
    misses[part] = {}
    for policy in policies:
        misses[part][policy] = {}
        for name in rows:
            misses[part][policy][name] = {
                cap: replay(rows[name][part], policy, cap,
                            scores[name][part] if policy == "ml" else None,
                            .2)["misses"] for cap in capacities}
summary = {}
for policy in policies:
    val_allocations = {a: misses["validation"][policy]["a"][a] +
                          misses["validation"][policy]["b"][1024-a]
                       for a in capacities}
    chosen = min(val_allocations, key=lambda a: (val_allocations[a], abs(a-512)))
    summary[policy] = {"validation_selected_a_entries": chosen,
                       "validation_total_misses": val_allocations[chosen],
                       "test_selected_total_misses": misses["test"][policy]["a"][chosen] +
                                                     misses["test"][policy]["b"][1024-chosen],
                       "test_equal_total_misses": misses["test"][policy]["a"][512] +
                                                  misses["test"][policy]["b"][512],
                       "test_curve": {str(a): misses["test"][policy]["a"][a] +
                                              misses["test"][policy]["b"][1024-a]
                                      for a in capacities}}
result = {"total_capacity_entries": 1024,
          "method": "Each worker has a private cache; validate static split on 60-80%, test on 80-100%. Offline miss-count probe, not online quota controller.",
          "summary": summary}
(ROOT / "results_quota_probe.json").write_text(json.dumps(result, indent=2))
print(json.dumps(summary, indent=2))
