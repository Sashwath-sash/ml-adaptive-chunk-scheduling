"""Exploratory ARC plus frozen-ML admission probe on already inspected tests."""
import json
from pathlib import Path

import joblib

from arc_reference_probe import arc_misses
from cache_admission_probe import feature_rows, read_rows, replay
from s3fifo_reference_probe import simulate as s3fifo_misses

ROOT = Path(__file__).resolve().parent
model = joblib.load(ROOT / "results_cache_three_source_v1/model.joblib")
inputs = {
    "scripted": ("data/browsetrace_full_400_sessions.csv", True),
    "llm": ("data/browsetrace_llm_full_901.csv", True),
    "nasa_aug": ("data/nasa_aug_last_100k_cache.csv", False),
    "calgary": ("data/calgary_last_100k_cache.csv", False),
}
result = {}
for name, (path, final_fraction) in inputs.items():
    rows = read_rows(ROOT / path)
    if final_fraction:
        rows = rows[int(len(rows) * .8):]
    scores = model.predict_proba(feature_rows(rows))[:, 1]
    keys = [key for key, _ in rows]
    result[name] = {"requests": len(rows),
                    "arc": arc_misses(keys, 512),
                    "ml_only": replay(rows, "ml", 512, scores, .2)["misses"],
                    "hybrid_arc_ml": arc_misses(keys, 512, scores, .2),
                    "s3fifo": s3fifo_misses(keys, 512),
                    "hybrid_s3fifo_ml": s3fifo_misses(keys, 512, scores >= .2)}
(ROOT / "results_hybrid_arc_probe.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
