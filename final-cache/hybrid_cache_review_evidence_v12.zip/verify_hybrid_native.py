"""Build and check native ARC/hybrid against independently replayed counts."""
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LINUX_ROOT = "/mnt/" + ROOT.drive[0].lower() + ROOT.as_posix()[2:]
PREFIX = ["wsl.exe", "--cd", LINUX_ROOT, "-e"]
subprocess.run(PREFIX + ["gcc", "-O3", "-std=c11", "-Wall", "-Wextra",
                         "cache_native.c", "-lm", "-o", "cache_native"], check=True)
offline = json.loads((ROOT / "results_hybrid_arc_probe.json").read_text())
inputs = {"scripted": "cache_native_input_three_source_scripted",
          "llm": "cache_native_input_three_source_llm",
          "nasa_aug": "cache_native_input_nasa_aug_v1",
          "calgary": "cache_native_input_calgary_v1"}
results = {}
for name, folder in inputs.items():
    baseline = json.loads((ROOT / {"scripted": "results_three_source_scripted_3runs",
                                  "llm": "results_three_source_llm_3runs",
                                  "nasa_aug": "results_nasa_aug_three_source_3runs",
                                  "calgary": "results_calgary_baselines_3runs"}[name] / "results.json").read_text())
    checksum = baseline["repeats"][0][0]["checksum"]
    results[name] = {}
    for policy, expected in (("arc", offline[name]["arc"]),
                             ("hybrid_arc", offline[name]["hybrid_arc_ml"]),
                             ("hybrid_s3fifo", offline[name]["hybrid_s3fifo_ml"])):
        cmd = PREFIX + ["./cache_native", f"{folder}/test_trace.txt",
                        f"{folder}/model.txt", "1", policy, "--sync"]
        run = subprocess.run(cmd, input="\n", capture_output=True, text=True)
        if run.returncode:
            raise RuntimeError(f"{name} {policy}: {run.stderr}")
        record = json.loads(run.stdout.split("\n", 1)[1])["repeats"][0][0]
        assert record["direct_reads"] == expected, (name, policy, expected, record)
        assert record["checksum"] == checksum, (name, policy, checksum, record)
        results[name][policy] = record
    print(f"PASS {name}: ARC {results[name]['arc']['direct_reads']}, "
          f"hybrid ARC {results[name]['hybrid_arc']['direct_reads']}, "
          f"hybrid S3 {results[name]['hybrid_s3fifo']['direct_reads']}", flush=True)
(ROOT / "results_hybrid_native.json").write_text(json.dumps(results, indent=2))
