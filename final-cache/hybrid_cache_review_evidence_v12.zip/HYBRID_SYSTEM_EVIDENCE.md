# Machine Learning Assisted Adaptive I O Chunk Caching for Multiprocessing Workloads

## What the system does

The project is a user-space Linux direct-I/O cache prototype for fixed 4-KiB chunks. A C process receives a sequence of chunk requests, checks a bounded 512-entry cache, and performs an aligned `O_DIRECT` read from a deterministic backing file on a miss. The model predicts near-term reuse from the current request and causal past-only features. If its frozen score is below 0.2, the chunk is served from the backing file but not admitted to the cache. If above, a conventional ARC or S3-FIFO replacement policy manages it. The ML model is trained and exported in Python; all online requests, prediction-tree traversal, cache lookup, eviction, and direct reads occur in C on Linux under WSL. This is **not a kernel patch** and does not contain original web response bodies.

The title remains close to Review 2 while the scope changes from CPU chunk scheduling to I/O chunk caching. The student chose this change after the CPU-scheduling experiments did not show a reliable overall-time improvement. The earlier Review 2 implementation is not this implementation. The change must be disclosed to the reviewer; it has not been represented as already approved.

## The problem and measured benefit

An ordinary cache inserts every missed chunk. When many chunks are used once, they displace chunks that will be used again. The model estimates reuse within the next 1,024 requests, and the policy bypasses predicted one-time chunks. The primary metric is the number of 4-KiB direct reads required to serve the same complete request stream with identical output. Fewer direct reads mean fewer backing-file read calls and fewer bytes *requested* from storage in this prototype. They do not prove fewer physical device transactions or shorter network latency.

### Native direct-read counts at 512 entries

| Held-out stream | Requests | ARC | ML-filtered ARC | Reduction | S3-FIFO | ML-filtered S3 | Reduction |
|---|---:|---:|---:|---:|---:|---:|---:|
| BrowseTrace A | 16,491 | 7,430 | 7,104 | 4.4% | 7,773 | 7,336 | 5.6% |
| BrowseTrace B | 71,557 | 17,913 | 17,740 | 1.0% | 18,950 | 18,586 | 1.9% |
| NASA August | 100,000 | 8,792 | 8,130 | 7.5% | 8,349 | 8,048 | 3.6% |
| Calgary | 100,000 | 16,493 | 15,718 | 4.7% | 15,406 | 15,177 | 1.5% |

The C read counts exactly match separate Python replay implementations for ARC and S3-FIFO. Every compared policy returns the same checksum on each stream. The gain is relative to each *parent policy*, not proof of the best cache policy overall: ML-only beats the ARC hybrid on BrowseTrace A; ARC beats ML-only on BrowseTrace B; plain S3-FIFO beats ML-filtered ARC on Calgary. The observed consistent admission-filter improvement is the defensible result.

### Five-run native loop timing in seconds

| Stream | ARC | ML ARC | S3-FIFO | ML S3-FIFO |
|---|---:|---:|---:|---:|
| BrowseTrace A | 1.192 | 1.140 | 1.303 | 1.208 |
| BrowseTrace B | 2.866 | 2.894 | 3.081 | 3.055 |
| NASA August | 1.398 | 1.289 | 1.322 | 1.375 |
| Calgary | 2.835 | 2.584 | 2.456 | 2.424 |

These are medians of five alternating-order runs on one WSL host. Timings varied between sessions and include the complete online loop but exclude backing-file creation, model loading, and training. **The hybrid is not reliably faster**: ML ARC is slower than ARC on BrowseTrace B and ML S3 is slower than S3 on NASA August. The data support read reduction, not a general wall-clock speedup.

## Data and experimental control

BrowseTrace A and B came from [BrowseTrace](https://github.com/landigf/BrowseTrace). The model's training partition is the first 60% of each family; validation is the next 20%; the last 20% is tested. NASA July and August logs came from the [NASA HTTP archive mirror](https://github.com/greymd/NASA-HTTP). The model additionally trains on 150,000 earlier valid July GET responses and validates on the next 50,000. The final 100,000 requests in the extracted July slice were excluded after a previously trained model had failed on them. NASA August's last 100,000 valid GET responses are a later-time test from the same server. Calgary's last 100,000 valid GET responses came from a [different server's archive](https://ita.ee.lbl.gov/html/contrib/Calgary-HTTP.html); filenames were anonymized by the source archive. Extracted CSVs and SHA-256 manifests are packaged. Original compressed NASA/Calgary logs are excluded from the shareable ZIP.

The frozen HGB predictor has 100 stages and a 0.2 admission threshold, selected on the three validation slices. Features are log response size, log prior key count, log time since prior request for the key, log prior host request count, path length, static-file indicator, query indicator, and key length. They use current request metadata and prior counts only. The future-reuse label is used during training, never online. The model outputs the same exported tree ensemble in all four held-out tests.

**Chronology matters:** the plain ML policy's failed NASA July transfer (13,236 reads versus 11,040 for S3-FIFO) was observed before the three-source training redesign. ML-filtered ARC was probed on BrowseTrace and NASA August before Calgary was acquired; Calgary was a new-server test of that rule. ML-filtered S3 was explored only after inspecting Calgary's plain-policy baseline, so Calgary is **not** a blind final test for that particular hybrid. No claim of formal independent validation of the final choice is made.

## Architecture and modules

Request trace and metadata -> C parser -> resident-chunk lookup. A hit returns the cached 4-KiB block. A miss performs an aligned direct read, computes the eight causal features, traverses the frozen HGB trees with exact early stopping, then either bypasses admission or passes the block to ARC or S3-FIFO. The output checksum is accumulated for every request. Separate worker processes may replay alternating request shards with private caches; this is not a coordinated shared-memory cache.

`train_three_source_cache.py` fits the frozen model and chooses stage/threshold on validation only. `export_cache_native.py` writes numeric traces and model nodes. `cache_native.c` performs the Linux online loop. `arc_reference_probe.py` and `s3fifo_reference_probe.py` are independent miss-count references. `verify_hybrid_native.py` compiles and checks the C policies against those references and checks data correctness. `benchmark_hybrid_native.py` runs alternating-order native timing. `verify_three_source.py` verifies older saved results and hashes. `demo_hybrid_final.py` is the reviewer demonstration entry point.

## Demonstration

From the extracted package folder on the same Windows/WSL host:

```powershell
python demo_hybrid_final.py
python demo_hybrid_final.py --live calgary
```

The saved mode prints the four-stream evidence after integrity checks. Live mode compiles the current C program with WSL GCC and reruns the frozen model on the chosen held-out trace. Exact read counts and output checksums should match; timing can differ. `--live scripted`, `--live llm`, and `--live nasa_aug` are also supported. Training requires the versions listed in `requirements_final_cache.txt`; demonstrating the saved model requires only Python standard library plus WSL GCC. Two hybrid modes passed AddressSanitizer and UndefinedBehaviorSanitizer on a complete 16,491-request stream.

## Boundaries before academic submission

ML admission is not a new general idea. The [S3-FIFO paper](https://juncheng.seas.harvard.edu/publication/sosp23-s3fifo.pdf) itself compares against learned admission to flash cache, while [ARC](https://research.ibm.com/publications/arc-a-self-tuning-low-overhead-replacement-cache) predates this project. The contribution supported here is a particular frozen causal predictor integrated with two replacement policies and evaluated in a native direct-I/O prototype, including failed transfers and out-of-source tests. It is **not** evidence of previously unpublished global novelty or superiority to production caches. There is no in-kernel deployment, no original response-body replay, no physical I/O counter, no official optimized S3-FIFO implementation, no capacity sweep, and no broad modern-dataset evaluation. A paper must state these constraints.

The Review 3 guideline also requires an original student-written paper and a 30-paper recent peer-reviewed survey. This technical evidence is suitable to inspect and demonstrate, but **it is not the complete final academic submission**. The student must disclose the scope change to the reviewer and write/verify the required paper in their own voice; the program should not be represented as a kernel integration or a globally novel cache policy.
