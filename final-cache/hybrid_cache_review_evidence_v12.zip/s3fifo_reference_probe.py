"""Independent S3-FIFO miss-count probe from SOSP'23 Algorithm 1, uniform 4-KiB blocks.

This is a local Python implementation for sensitivity analysis, not the authors'
optimized implementation and not a comparable native wall-time benchmark.
"""
import argparse
import json
from collections import OrderedDict
from pathlib import Path


def requests(path):
    with path.open() as stream:
        count, _, _ = map(int, stream.readline().split())
        result = [int(line.split()[0]) for line in stream]
    assert len(result) == count
    return result


def simulate(ids, capacity=512, admit=None):
    small_max = max(1, round(capacity * .1))
    main_max = capacity - small_max
    small, main, ghost = OrderedDict(), OrderedDict(), OrderedDict()
    misses = 0

    def evict_main():
        while main:
            key, freq = main.popitem(last=False)
            if freq > 0:
                main[key] = freq - 1
            else:
                return
        raise AssertionError("empty main queue")

    def evict_small():
        while small:
            key, freq = small.popitem(last=False)
            if freq > 1:
                freed = False
                if len(main) >= main_max:
                    evict_main()
                    freed = True
                main[key] = 0
                if freed:
                    return
            else:
                ghost[key] = None
                if len(ghost) > main_max:
                    ghost.popitem(last=False)
                return
        raise AssertionError("empty small queue")

    for index, key in enumerate(ids):
        if key in small:
            small[key] = min(small[key] + 1, 3)
            continue
        if key in main:
            main[key] = min(main[key] + 1, 3)
            continue
        misses += 1
        if admit is not None and not admit[index]:
            continue
        while len(small) + len(main) >= capacity:
            if len(small) >= small_max:
                evict_small()
            else:
                evict_main()
        if key in ghost:
            del ghost[key]
            if len(main) >= main_max:
                evict_main()
            main[key] = 0
        else:
            small[key] = 0
    return misses


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    if args.output.exists():
        ap.error("output already exists")
    result = {}
    for name in ("scripted", "llm"):
        single = requests(args.root / f"cache_native_input_multitrace_{name}/test_trace.txt")
        shards = [requests(args.root / f"cache_native_shards_{name}/worker{w}/test_trace.txt") for w in (0, 1)]
        result[name] = {"single_requests": len(single), "single_misses": simulate(single),
                        "shard_requests": [len(x) for x in shards],
                        "shard_misses": [simulate(x) for x in shards]}
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
