"""Black-and-white figures from saved held-out results; no manually entered measurements."""
import argparse
import json
import statistics
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parent
POLICIES = ("lru", "second_touch", "two_queue", "s3fifo", "ml")
LABELS = ("LRU", "Second touch", "2Q", "S3-FIFO", "ML")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", type=Path, default=Path("final_cache_evidence.png"))
    args = ap.parse_args()
    if args.output.exists():
        ap.error("output already exists")
    fig, axes = plt.subplots(2, 2, figsize=(13, 7), layout="constrained")
    for col, name in enumerate(("scripted", "llm")):
        data = json.loads((ROOT / f"results_final5_sharded_{name}_fixed_5runs/results.json").read_text())
        for row, (field, ylabel) in enumerate((("sum_direct_reads", "Direct read calls, both workers"),
                                                 ("batch_wall_seconds", "Batch wall time (s), median of 5"))):
            ax = axes[row, col]
            values = [data["summary"][policy]["sum_direct_reads_per_batch"] if row == 0 else
                      statistics.median(run[field] for run in data["runs"] if run["policy"] == policy)
                      for policy in POLICIES]
            bars = ax.bar(range(5), values, color=["white", ".85", ".7", ".55", ".35"],
                          edgecolor="black", linewidth=.8)
            for bar, value in zip(bars, values):
                ax.text(bar.get_x() + bar.get_width()/2, bar.get_height(),
                        f"{value:,.0f}" if row == 0 else f"{value:.3f}",
                        ha="center", va="bottom", fontsize=8)
            ax.set_xticks(range(5), LABELS)
            ax.set_ylim(0, max(values)*1.17)
            ax.set_ylabel(ylabel)
            ax.set_title(("Scripted-control" if name == "scripted" else "Second trace") +
                         (" / reads" if row == 0 else " / time"), fontsize=11)
            ax.spines[["top", "right"]].set_visible(False)
    fig.suptitle("Two concurrent workers, different held-out request shards (512 x 4 KiB cache per worker)", fontsize=12)
    fig.savefig(args.output, dpi=200, facecolor="white")
    print(args.output.resolve())


if __name__ == "__main__":
    main()
