"""Derive a privacy-minimized external holdout from the NASA HTTP log."""
import csv
import argparse
import gzip
import hashlib
import json
import re
from collections import deque
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("--month", choices=("Jul", "Aug"), default="Jul")
ap.add_argument("--count", type=int, default=100_000)
ap.add_argument("--label", default="nasa_last_100k")
args = ap.parse_args()
if args.count <= 0:
    ap.error("count must be positive")
SOURCE = ROOT / f"data/NASA_access_log_{args.month}95.gz"
OUTPUT = ROOT / f"data/{args.label}_cache.csv"
MANIFEST = ROOT / f"data/{args.label}_manifest.json"
PATTERN = re.compile(rb'^\S+ - - \[[^]]+\] "GET (\S+) HTTP/[0-9.]+" 200 (\d+)$')
rows = deque(maxlen=args.count)
matched = 0
with gzip.open(SOURCE, "rb") as stream:
    for line in stream:
        parsed = PATTERN.match(line.strip())
        if parsed is None:
            continue
        path = parsed.group(1).decode("latin-1")
        if not path.startswith("/"):
            continue
        matched += 1
        rows.append(("http://nasa.ksc.nasa.gov" + path, int(parsed.group(2))))
with OUTPUT.open("w", newline="", encoding="utf-8") as stream:
    writer = csv.writer(stream)
    writer.writerow(("cache_key", "object_size_bytes"))
    writer.writerows(rows)
manifest = {"source_url": f"https://github.com/greymd/NASA-HTTP/blob/master/NASA_access_log_{args.month}95.gz",
            "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "matched_get_200_requests": matched, "selected_last_requests": len(rows),
            "derived_sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
            "selection": f"last {args.count} valid GET 200 requests, original order",
            "privacy": "client hosts and timestamps omitted; URL path and response bytes retained",
            "caveat": "External 1995 web-server request trace; not representative of modern OS workloads."}
MANIFEST.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(json.dumps(manifest, indent=2))
