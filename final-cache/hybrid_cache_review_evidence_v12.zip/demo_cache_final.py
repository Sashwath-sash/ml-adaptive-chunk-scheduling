"""Reviewer demo: verify saved evidence, optionally run a fresh live Linux replay."""
import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def show(name, path):
    data = json.loads(path.read_text())
    print(f"\n{name}: {data['requests']:,} held-out requests; {data['capacity']} x 4 KiB cache; {data['trees']}-tree model")
    print(f"{'Policy':<16}{'Direct reads':>14}{'Median loop (s)':>19}")
    for policy in ("lru", "second_touch", "two_queue", "s3fifo", "ml"):
        values = data["summary"][policy]
        print(f"{policy:<16}{values['direct_reads']:>14,}{values['median_wall_seconds']:>19.3f}")
    assert len({r[0]["checksum"] for r in data["repeats"]}) == 1
    print("Output checksum: identical across policies")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--live", choices=("scripted", "llm"), help="Run fresh WSL/GCC benchmark")
    args = ap.parse_args()
    subprocess.run([sys.executable, "verify_cache_final.py"], cwd=ROOT, check=True)
    for name in ("scripted", "llm"):
        show("Workload A" if name == "scripted" else "Workload B",
             ROOT / f"results_final5_{name}_5runs/results.json")
    if args.live:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        dest = ROOT / "demo_runs" / f"{args.live}_{stamp}"
        subprocess.run([sys.executable, "run_cache_native.py", "--input",
                        f"cache_native_input_multitrace_{args.live}", "--output", str(dest),
                        "--repeats", "1"], cwd=ROOT, check=True)
        show("LIVE " + args.live, dest / "results.json")
        print(f"Fresh result saved: {dest / 'results.json'}")


if __name__ == "__main__":
    main()
