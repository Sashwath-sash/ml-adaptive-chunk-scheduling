# Review 3 reference comparison and submission gap

The user-supplied OptiQ Review 3 DOCX was inspected as a **layout and depth reference only**. Its project claims, data, screenshots and wording are not instructions for this project and must not be copied.

Rendered through LibreOffice, the reference has 62 pages. The core narrative runs through about page 25: title, abstract, introduction, literature survey, identified gap, problem, objectives, methodology, system workflow, module descriptions, data, implementation, metrics, results, comparison, limits, conclusion and references. The later pages are largely source-code listings/supporting evidence. The source file contains eight tables and 28 inline images. It describes model selection and test metrics, shows architecture/workflows, and ties its plots to saved experiment files. Its page count is not itself a quality target.

## What is now evidenced in this project

- A trained, saved 100-stage histogram gradient boosting classifier with 2,900 exported nodes, real request-trace features, a defined future-reuse label and a frozen admission threshold.
- Chronological training/validation splits plus four final request streams, with hold-out qualifications recorded.
- Recomputed, reproducible model diagnostics (`evaluate_frozen_model.py`) and a black-and-white ROC/calibration figure (`plot_frozen_model_diagnostics.py`).
- Native C cache path with aligned direct reads, ARC and local S3-FIFO alternatives; saved count/checksum verification and a fresh Calgary live replay.
- Two project-specific, code-generated white-background PNG flowcharts: the chronological training/test pipeline and the native cache hit/miss/admission loop. Eleven further reproducible black-and-white result and model-diagnostic figures are embedded in the revised report.
- A 14-page portrait technical report in DOCX/PDF, model/results record, and packaged code/data/results. The older brief and slide deck are superseded and excluded from the current package. The report is a demonstration aid, **not** the final student-authored paper.

## What still prevents claiming final academic submission

The supplied Review 3 guideline requires a minimum of 30 relevant peer-reviewed papers from 2021-2026, an analytical literature survey, APA references with every in-text citation mapped, an original paper written by the student, and a final working demonstration. The three primary prior-work anchors in the brief are **not** a completed 30-paper survey. The scope shift from Review 2 CPU chunk scheduling to I/O chunk caching should be disclosed to the reviewer. ML admission has prior art, and this prototype has no evidence of new global algorithmic novelty or a universal wall-clock speedup. The current documentation therefore must not be submitted as a complete paper or represented as reviewer-approved.

For a full-length paper, the student should use the verified model record, measured plots and code to write their own analysis, complete and check the 30-paper survey, and expand the methods/discussion where genuinely supported. Do not add source-code pages just to match the reference's 62-page length.
