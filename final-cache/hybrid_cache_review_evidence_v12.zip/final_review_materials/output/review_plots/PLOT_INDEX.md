# Review 3 visualization gallery

These ten black-and-white PNGs are generated from the project's saved native benchmark JSON and frozen-model diagnostics. Rebuild them from the project directory with `python plot_review_gallery.py`. The exact plotted benchmark aggregates are also in `plot_values.csv`.

| File | What it shows |
|---|---|
| `01_direct_read_calls.png` | Absolute aligned 4 KiB read calls for ARC, ML+ARC, local S3-FIFO, and ML+S3-FIFO on four streams. Lower is better. |
| `02_read_reduction_percent.png` | Percent fewer read calls from adding ML admission to each parent policy. Each hybrid is compared only with its own parent. |
| `03_timing_all_runs.png` | Every one of the five saved elapsed-time runs per policy and stream; vertical ticks mark medians. The spread is visible and these are **not** confidence intervals. |
| `04_median_time_change.png` | Relative difference between saved five-run medians. Negative bars mean the ML hybrid was slower. |
| `05_reads_vs_time_tradeoff.png` | Both measured effects together: reduced reads on the horizontal axis and median time improvement on the vertical. Two cases saved reads but took longer. |
| `06_cache_hit_rates.png` | Hit rate calculated from the measured hits and misses on each native replay. |
| `07_model_quality_and_prevalence.png` | Held-out ROC AUC, average precision, and positive-label share for the frozen reuse predictor. |
| `08_precision_recall_at_threshold.png` | Precision and recall at the actual 0.2 model-admission threshold. |
| `09_classification_outcomes.png` | True/false positive/negative proportions at that threshold. |
| `10_early_stream_misses.png` | Exact cumulative miss checkpoints after 1,024, 2,048 and 4,096 requests. This is only early-stream behavior, not a continuous full-trace curve. |

The classifier target is reuse of the same key within the next 1,024 trace requests. The frozen model is a 100-stage histogram gradient-boosting classifier using eight causal features; see `MODEL_AND_RESULTS_RECORD.md` in the project root for its training split, features, caveats, and test boundary. These figures do not claim a new general cache algorithm, physical device I/O savings, or a stable speedup. Timing is noisy on this host. The S3-FIFO here is a local implementation, not a verified reproduction of the official optimized one.
