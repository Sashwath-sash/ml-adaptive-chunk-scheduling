"""Plot measured read and loop-time differences in black and white."""
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
offline = json.loads((ROOT / "results_hybrid_arc_probe.json").read_text())
arc = json.loads((ROOT / "results_hybrid_native_benchmark.json").read_text())
arc["calgary"] = json.loads((ROOT / "results_calgary_hybrid_arc_5runs.json").read_text())["calgary"]
s3 = json.loads((ROOT / "results_hybrid_s3_native_benchmark.json").read_text())
names = ("scripted", "llm", "nasa_aug", "calgary")
labels = ("BrowseTrace A", "BrowseTrace B", "NASA August", "Calgary")
read_arc = [100 * (offline[n]["arc"] - offline[n]["hybrid_arc_ml"]) / offline[n]["arc"] for n in names]
read_s3 = [100 * (offline[n]["s3fifo"] - offline[n]["hybrid_s3fifo_ml"]) / offline[n]["s3fifo"] for n in names]
time_arc = [100 * (arc[n]["arc"]["median_loop_seconds"] - arc[n]["hybrid_arc"]["median_loop_seconds"])
            / arc[n]["arc"]["median_loop_seconds"] for n in names]
time_s3 = [100 * (s3[n]["s3fifo"]["median_loop_seconds"] - s3[n]["hybrid_s3fifo"]["median_loop_seconds"])
           / s3[n]["s3fifo"]["median_loop_seconds"] for n in names]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10})
fig, axes = plt.subplots(2, 1, figsize=(8.4, 7.0), sharex=True)
x = np.arange(len(names))
for ax, left, right, ylabel in ((axes[0], read_arc, read_s3, "Direct-read reduction (%)"),
                                (axes[1], time_arc, time_s3, "Median loop-time reduction (%)")):
    ax.bar(x - .18, left, width=.34, facecolor="white", edgecolor="black", hatch="///", label="ML admission + ARC")
    ax.bar(x + .18, right, width=.34, facecolor="0.62", edgecolor="black", label="ML admission + S3-FIFO")
    ax.axhline(0, color="black", linewidth=.8)
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", color="0.82", linewidth=.5)
    ax.set_axisbelow(True)
    for center, value in zip(x - .18, left):
        ax.text(center, value + (.18 if value >= 0 else -.18), f"{value:+.1f}",
                ha="center", va="bottom" if value >= 0 else "top", fontsize=8)
    for center, value in zip(x + .18, right):
        ax.text(center, value + (.18 if value >= 0 else -.18), f"{value:+.1f}",
                ha="center", va="bottom" if value >= 0 else "top", fontsize=8)
    ax.margins(y=.22)
axes[0].legend(frameon=False, ncol=2, loc="upper right")
axes[0].set_title("Frozen ML admission compared with its parent cache policy")
axes[1].set_xticks(x, labels)
axes[1].set_xlabel("Held-out request stream")
axes[1].text(0, -.31, "Positive means fewer reads or lower time; timing is noisy and not a cross-machine guarantee.",
             transform=axes[1].transAxes, fontsize=8)
fig.tight_layout()
fig.savefig(ROOT / "hybrid_cache_evidence_bw.png", dpi=180, bbox_inches="tight")
print(ROOT / "hybrid_cache_evidence_bw.png")
