# Final implementation evidence - for the student's review preparation

## Identity and continuity

Proposed working title: **Machine-Learning-Assisted Adaptive I/O Chunk Management for Multiprocessing Workloads**. The earlier Review 2 investigated CPU work-chunk scheduling; its measured completion-time result was not consistently better than simple scheduling. This final prototype keeps the OS theme of bounded chunk management but moves the controlled decision to *which I/O chunks are admitted to a small user-space cache*. This is a scope change and should be explained to the reviewer, not disguised as the old scheduler.

The concrete question is: can an online learned admission decision reduce required direct-read requests at fixed cache capacity, including when two workers process different request streams? It is not a Linux kernel patch. The contribution demonstrated here is a particular end-to-end prototype and evaluation, **not** a claim that learned caching or gradient-boosted trees were invented in this project.

## Actual system

```text
Released URL-request sequence -> 4 KiB chunk ID -> per-worker cache lookup
                                                | hit: return cached bytes
                                                | miss: aligned Linux O_DIRECT pread
                                                |       verify deterministic block marker
                                                +-> decide admission: LRU / second touch /
                                                    simplified 2Q / frozen ML model
```

On each miss the ML policy computes eight causal features: log object size, log prior count for the key, log requests since last access (or an unseen sentinel), log prior requests to that host, path length, static-file extension indicator, query indicator, and key length. It uses a 100-stage histogram gradient-boosted classifier trained to predict reuse within the next 1,024 requests. A probability of at least 0.2 admits the block; admitted blocks are replaced by LRU. Histories update *after* each decision. No future feature or test label is used at inference.

The model is trained in Python/scikit-learn and exported as frozen tree nodes. In the executable, cache lookup, feature computation, tree traversal, replacement, and aligned Linux direct I/O run in C. The timed request loop includes these online operations. A safe tree-bound check can stop inference early only when every remaining tree is unable to reverse the admission decision; its miss counts were verified unchanged. Model loading and creation of the backing file are outside the loop for all policies. Each policy returns the same verified block checksum. The cache holds 512 x 4,096-byte chunks (2 MiB) per worker.

## Dataset and split

The two released request sequences are from [BrowseTrace](https://github.com/landigf/BrowseTrace), a research dataset whose authors explicitly warn that offline cache replay is not a measured network speedup. Workload A (scripted-control requests) has 82,455 requests; Workload B (a separately collected sequence labelled LLM-agent traffic by the dataset authors) has 357,782 requests. **No LLM is part of this project or its model.** The second trace's legacy filename contains `901`, but the source says that number is not a verified independent-session count. Data are attributed under CC BY 4.0.

Each sequence is split in stored order: first 60% for training, next 20% for model-size/threshold validation, final 20% untouched until final evaluation. The two training portions are combined for one model. A validation-only objective minimizes the *worst* miss ratio relative to second-touch across the two workload types. This selected 100 stages and threshold 0.2. Final tests contain 16,491 scripted-control requests and 71,557 LLM-labelled requests. Online features reset at each partition boundary, so cache and request-history state do not cross into the held-out tests.

The released CSV provides request identities and sizes, not original response bodies. Each unique request key is mapped to a deterministic synthetic 4 KiB block in a real WSL ext4 file. Therefore the test verifies real aligned direct-read calls, cache contents, and checksums, but **does not** measure original web-object delivery, physical disk transactions, or network latency.

## Held-out single-stream measurements

Five repetitions per test partition, rotating policy order across five policies. Values below are median request-loop wall time and exact direct-read call counts. The newer five-policy run was slower overall than some earlier four-policy runs, a sign that local timing is environmentally variable.

| Partition | Policy | Direct reads | Median time (s) |
|---|---|---:|---:|
| Workload A, 16,491 requests | LRU | 8,793 | 2.512 |
| | Second touch | 7,543 | 2.625 |
| | Simplified 2Q | 7,655 | 2.673 |
| | S3-FIFO (local implementation) | 7,773 | 2.286 |
| | ML + LRU | **6,707** | **1.923** |
| Workload B, 71,557 requests | LRU | 19,713 | 5.874 |
| | Second touch | 19,209 | 5.847 |
| | Simplified 2Q | 18,683 | **5.243** |
| | S3-FIFO (local implementation) | 18,950 | 6.954 |
| | ML + LRU | **18,556** | 7.515 |

On Workload A, ML makes 836 fewer reads (11.1%) than second touch and is fastest in this five-policy run. On Workload B, ML makes only 127 fewer reads (0.68%) than simplified 2Q but is much slower by this run's median time. The small read difference and highly variable time prevent a broad superiority claim. Ranges and every repetition are in the saved JSON. S3-FIFO's C miss counts match an independent Python implementation based on the paper's Algorithm 1, but this local C version is not the authors' optimized implementation, so its wall time should not be used as a state-of-the-art performance comparison.

## Two different concurrent worker streams

The final 20% of each sequence was interleaved into even/odd request shards. Two processes each get a different shard, a separate cache and backing file, and a synchronized start of their timed loops. This measures concurrent CPU/storage contention and batch completion, not a shared cache. Five repetitions per trace family:

| Two-worker workload | Policy | Total direct reads | Median batch time (s) |
|---|---|---:|---:|
| Workload A shards | LRU | 8,947 | 1.516 |
| | Second touch | 9,654 | 1.526 |
| | Simplified 2Q | 8,781 | 1.284 |
| | S3-FIFO (local implementation) | 9,544 | 1.379 |
| | ML + LRU | **7,912** | **1.139** |
| Workload B shards | LRU | 21,652 | 3.237 |
| | Second touch | 21,399 | 3.015 |
| | Simplified 2Q | 21,325 | 3.296 |
| | S3-FIFO (local implementation) | 22,248 | 3.222 |
| | ML + LRU | **20,592** | **2.717** |

For these sharded tests, ML reduces reads against the strongest listed non-ML read baseline by 9.9% (Workload A 2Q) and 3.4% (Workload B 2Q). Its median batch time is lower than the fastest listed baseline in these particular repetitions. However, those times varied substantially between benchmark sessions and should be treated as local observations, not a statistical or cross-machine performance guarantee.

The black-and-white figure generated from these JSON files is `final_cache_evidence_v2.png`. The code is `plot_cache_final.py`; the bars are measurements, not illustrative numbers.

## Failed approaches kept visible

1. Earlier CPU chunk scheduling improved some balance metrics but not reliable total completion time on this one-physical-core / two-logical-CPU machine.
2. The first single-trace 40-tree cache model saved reads and time on scripted-control but *lost both* to second-touch on the entire separate LLM-labelled trace. It was not a generalization result.
3. Training one model on the training portions of both workload types and selecting on their validation portions fixed that particular transfer failure on the held-out final portions. This does not guarantee generalization to a third workload.
4. Python-based online cache management was slower despite fewer reads. The complete native C loop was needed for the measured runtime result.

## Demonstration and verification

From this directory on Windows with WSL/GCC available:

```powershell
python demo_cache_final.py
python demo_cache_final.py --live scripted
python verify_cache_final.py
```

The first command verifies source hashes, chronological split counts, offline/native misses, identical data checksums, and concurrent totals, then displays both saved five-run tables. `--live scripted` compiles C under WSL, runs fresh policies, and saves its JSON under `demo_runs/`. For the larger live test use `--live llm` (takes longer). `run_cache_concurrent.py` reproduces separate-worker tests; `train_multitrace_cache.py` trains the frozen model. The actual implementation is `cache_native.c`, with exported inputs under `cache_native_input_multitrace_*` and sharded inputs under `cache_native_shards_*`.

The native C executable was also compiled with AddressSanitizer and UndefinedBehaviorSanitizer and passed a full scripted test. The saved evidence is verified by `verify_cache_final.py`.

A second clean invocation of `train_multitrace_cache.py` reproduced the same model export byte-for-byte (SHA-256 `71f5ab3196cbae53b51566096d05146faae4b8404ab11850aaaf431d1525b16d`).

## Limitations and honest novelty boundary

This is a user-space OS-style I/O cache prototype, **not** a kernel-integrated scheduler. The original web response bodies are unavailable. `O_DIRECT` requests bypass the Linux page cache, but requested direct-read bytes are not measured physical device traffic; host and drive caches may still apply. The test computer has one physical core with two logical CPUs. Two processes have private caches; there is no shared-cache coherence or distributed coordination. Simplified 2Q and the local S3-FIFO implementation match independent replay counts but are not optimized production implementations. Other strong cache algorithms (for example GDSF and ARC), more capacities, and further independent traces remain untested. Thus no global state-of-the-art claim is supported.

Prior work on learned cache replacement/admission exists; for example [LeCaR](https://www.usenix.org/system/files/conference/hotstorage18/hotstorage18-paper-vietri.pdf). More recent systems such as [S3-FIFO](https://juncheng.seas.harvard.edu/publication/sosp23-s3fifo.pdf) and [3L-Cache](https://www.usenix.org/system/files/fast25-zhou-wenbin.pdf) show why a serious paper must compare against stronger methods. The defensible *project-level* contribution is the frozen cross-workload reuse model integrated into a bounded C direct-I/O chunk cache, with causal features, validation-only selection, full online timing, two distinct concurrent streams, and explicit negative/positive results. Do not say this combination has never been published without a much stronger literature search.

## Submission boundary

The supplied Review 3 guideline requires a student-written original paper, at least 30 relevant peer-reviewed 2021-2026 papers, APA references with matching in-text citations, a clear research gap/novelty, source code, and a working demonstration. **This evidence pack is not that final paper.** The old scheduling literature cannot silently stand in for a changed caching topic. The student must review the title/scope change with the supervisor, conduct and write the new literature analysis, and submit their own verified paper. No fabricated results or unsupported novelty statement should be added to bridge that gap.
