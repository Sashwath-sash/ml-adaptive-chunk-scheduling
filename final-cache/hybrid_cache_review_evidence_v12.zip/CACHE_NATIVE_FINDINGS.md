# Native ML-assisted chunk cache: current result

## What is implemented

An online C cache-admission prototype. The request order and URL identities come from the public BrowseTrace `crawler` trace. Each distinct URL maps to a deterministic synthetic 4 KiB block in a real WSL ext4 file. On a miss, the program performs an aligned Linux `O_DIRECT` read. All policies return the same verified data checksum. The bounded cache holds 512 blocks (2 MiB). A 40-stage histogram-gradient-boosted model predicts reuse using only request-time and prior-request features. Both inference and cache-management overhead are included in timed request replay. Backing-file construction and model loading are excluded equally from the timed loop.

The model was trained on the chronological first 60% of the trace; 20% was used for threshold/model-size selection; the final 20% (16,491 requests) was held out for this result. The 40-stage size was chosen on validation within 2% of the best validation miss count. The C model gives 6,876 misses, matching the offline held-out replay exactly.

## Nine-run held-out comparison

| Policy | Median request-loop wall time | Direct read calls | Requested direct-read bytes |
|---|---:|---:|---:|
| LRU | 1.761 s | 8,793 | 36,016,128 |
| Second-touch admission + LRU | 1.437 s | 7,543 | 30,896,128 |
| ML admission + LRU | 1.365 s | 6,876 | 28,164,096 |

Against the strongest of these two simple baselines, ML requests 667 fewer direct reads (8.84%) and has a 5.03% lower median replay wall time. ML is faster than second-touch in 7/9 paired runs. Ranges overlap, so the small wall-time advantage is not a robust general-speedup conclusion. The direct-read count reduction is deterministic for this trace and policy configuration.

Earlier Python and partial-native versions were slower despite saving reads. Full native integration removed the Python per-request overhead and changed the measured result. This is not evidence that ML always wins, nor a claimed novel cache algorithm. Learned cache policies already exist. The contribution here is an OS-adjacent workload-specific prototype and measured comparison.

## Important boundaries

- This is user-space Linux direct I/O, not a modified Linux scheduler or kernel page cache.
- Original response bodies are unavailable; block contents are deterministic synthetic data, while request identities/order come from the public trace.
- Direct-read calls/bytes are counted exactly; physical disk traffic and original website/network latency were not measured. `O_DIRECT` bypasses the page cache but does not eliminate host/storage hardware caching.
- A second independent trace was tested with the model/threshold frozen. It **did not transfer**: on the 357,782-request LLM-labelled sequence, ML made 91,850 direct-read calls and had 16.911 s median loop time (three runs); second-touch made 88,916 calls and had 16.226 s median time. LRU made 95,251 calls and had 17.115 s median time. This is a negative result, not a general speedup.
- Two concurrent worker processes were also tested on the original held-out sequence. They start their timed loops together, each with its own cache and backing file. Across five batches, ML had 1.374 s median batch wall time and 13,752 total direct-read calls; second-touch had 1.533 s and 15,086 calls; LRU had 1.724 s and 17,586 calls. One of five paired batches favored second-touch on time. This is CPU/storage contention between replicated streams, not a shared cache or distinct task partitioning.
- Other capacities, other traces and stronger production cache baselines remain needed. The cross-trace failure is especially important: a practical design would need workload detection or a safe fallback, evaluated on fresh data.

## Reproduce

From this folder on Windows with WSL and GCC available:

`python run_cache_native.py --output results_cache_native_new --repeats 9`

The runner builds `cache_native.c` with GCC under WSL and writes JSON with every repetition and a summary. The input is `cache_native_input_40/`; the full training and export pipeline is `cache_admission_probe.py`, `cache_stage_select.py`, and `export_cache_native.py`. The current saved measurements are in `results_cache_native_40_9runs/results.json`. The runner refuses to overwrite an existing output directory.

For the independent trace, use `python run_cache_native.py --input cache_native_input_llm_40 --output results_external_new --repeats 3`; saved data: `results_cache_native_llm_40_3runs/results.json`. For concurrent replay, use `python run_cache_concurrent.py --workers 2 --repeats 5 --output results_concurrent_new`; saved data: `results_cache_concurrent_2w_5runs/results.json`.

Trace source: https://github.com/landigf/BrowseTrace (released under CC BY 4.0). Prior learned-cache example: https://www.usenix.org/system/files/conference/hotstorage18/hotstorage18-paper-vietri.pdf .
