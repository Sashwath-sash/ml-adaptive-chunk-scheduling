"""Check native frequency-admission policy against independent Python replay."""
import json
import subprocess
from pathlib import Path

from cache_admission_probe import read_rows, replay_tinylfu


ROOT = Path(__file__).resolve().parent
LINUX_ROOT = "/mnt/" + ROOT.drive[0].lower() + ROOT.as_posix()[2:]
results = {}
for name, source in (
    ("scripted", "data/browsetrace_full_400_sessions.csv"),
    ("llm", "data/browsetrace_llm_full_901.csv"),
):
    rows = read_rows(ROOT / source)
    test = rows[int(len(rows) * .8):]
    expected = replay_tinylfu(test, 512)["misses"]
    folder = f"cache_native_input_multitrace_{name}"
    command = ["wsl.exe", "--cd", LINUX_ROOT, "-e", "./cache_native",
               f"{folder}/test_trace.txt", f"{folder}/model.txt", "3", "tiny_lfu", "--sync"]
    run = subprocess.run(command, input="\n", capture_output=True, text=True, check=True)
    payload = json.loads(run.stdout.split("\n", 1)[1])
    records = [repeat[0] for repeat in payload["repeats"]]
    observed = {record["direct_reads"] for record in records}
    assert observed == {expected}, (name, observed, expected)
    results[name] = {"requests": len(test), "direct_reads": expected,
                     "wall_seconds": [record["wall_seconds"] for record in records],
                     "checksum": records[0]["checksum"]}
print(json.dumps(results, indent=2))
