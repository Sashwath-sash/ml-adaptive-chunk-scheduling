# ML-assisted adaptive I/O chunk management - review evidence package

Start with `final_review_materials/output/Review3_Project_Technical_Report.pdf` for the revised illustrated explanation. Then use `MODEL_AND_RESULTS_RECORD.md` for the trained model, eight features, settings, data splits and native outcomes. `HYBRID_SYSTEM_EVIDENCE.md` and `THREE_SOURCE_FINDINGS.md` retain the earlier evidence and negative transfer test. This package is technical evidence, **not** a student-authored submission paper.

The portrait evidence report is `final_review_materials/output/Review3_Project_Technical_Report.docx` (also exported as PDF). It includes 13 numbered figures: revised training and request-loop flowcharts, ten result/model plots, and ROC/calibration. Each figure has an explanation below it. The ten PNG plots, their plotted CSV values, and a figure guide are in `final_review_materials/output/review_plots/`; regenerate them with `python plot_review_gallery.py`. Regenerate the two flowcharts with `python draw_cache_flowcharts.py`. The report is still a technical companion, not the required original student-written paper or 30-paper survey.

Run `python demo_hybrid_final.py` for the saved four-stream comparison and `python demo_hybrid_final.py --live calgary` for a fresh Linux demonstration. `verify_hybrid_native.py` recompiles and checks the hybrid read counts against independent Python replays. `demo_cache_final.py` remains available for the older two-source model; do not mix versions. The black-and-white result figure is `hybrid_cache_evidence_bw.png`. The added `evaluate_frozen_model.py`, `plot_frozen_model_diagnostics.py`, `plot_review_gallery.py`, and `draw_cache_flowcharts.py` regenerate the model checks and explanatory figures using the project's Python environment.

To show the project live on the Windows machine where it was built:

1. Install/enable WSL with GCC. Python 3 is required; the live native demo itself needs only Python standard library on Windows.
2. In this folder run `python demo_hybrid_final.py` to verify the current four-stream results.
3. Run `python demo_hybrid_final.py --live calgary` to compile and run a fresh Linux direct-I/O demonstration. Its exact read counts and checksum should match; wall time can vary.
4. Show `hybrid_cache_evidence_bw.png` for the read-count and timing comparison, and `final_review_materials/output/frozen_model_diagnostics_bw.png` for classifier discrimination and calibration.

For retraining or regenerating the figure, install `requirements_final_cache.txt` in a Python environment. The selected model and threshold were frozen before the recorded final held-out replays, subject to the chronology caveats in `MODEL_AND_RESULTS_RECORD.md`. `verify_hybrid_evidence.py` checks the saved results and inputs. It never modifies them.

The original Review 2 CPU-chunk-scheduling code and presentation are **not** part of this final package. The student chose a scoped change to I/O chunk caching after the earlier CPU experiments failed to show a reliable overall-time gain. `REVIEW2_TO_FINAL_TRANSITION.md` explains the continuity and difference. The change has not been described as teacher-approved; it should be disclosed in Review 3. `final_review_materials/REFERENCE_GAP_CHECK.md` records why this evidence package is not yet a complete academic submission: the 30-paper survey, APA cross-check and original student-written paper remain.
